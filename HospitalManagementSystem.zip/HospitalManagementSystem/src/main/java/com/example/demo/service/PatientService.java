package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Patient;

public interface PatientService {
	
	Patient signIn(Patient patient);
    Patient signUp(Patient patient);
   
    void updatePatient(Patient patient);
    List<Patient> getAllPatients();
    void deletePatient(Integer id);
    Patient getPatientById(int patientId);
    
	
	

}
