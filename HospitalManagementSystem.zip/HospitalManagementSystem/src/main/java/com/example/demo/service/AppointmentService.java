package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.entity.Appointment;

public interface AppointmentService {
	    List<Appointment> getAllAppointments();
	    void bookAppointment(int doctorId,int patientId,Appointment appoint);
	    Optional<Appointment> getAppointmentById(Integer id);
	   
	    void viewAppointments(Integer doctorId);
	    List<Appointment> getAppointmentsByDoctorId(Integer doctorId);

}
