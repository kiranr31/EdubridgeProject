package com.example.demo.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Doctor;
import com.example.demo.repository.DoctorRepository;
import com.example.demo.service.DoctorService;
@Service
public class DoctorServiceImpl  implements DoctorService {
@Autowired
private DoctorRepository doctorRepository;
	@Override
	public  Doctor signIn( Doctor doctor) {
		
           return doctorRepository.findByEmailAndPassword(doctor.getEmail(),doctor.getPassword());
        }
    
	
	

	@Override
	public Doctor signUp(Doctor doctor) {
     return  doctorRepository.save(doctor);
	}
     
     @Override
     public void updateDoctor(Doctor doctor) {
         doctorRepository.save(doctor);
     }

    

     @Override
     public void deleteDoctor(Integer id) {
         doctorRepository.deleteById(id);
     }




 	@Override
 	public List<Doctor> getAllDoctors() {
 		// TODO Auto-generated method stub
 		return doctorRepository.findAll();
 	
   }




	@Override
	public Doctor getDoctorById(int doctorId) {
		// TODO Auto-generated method stub
		return doctorRepository.getById(doctorId);
	}

		
}
		
	






	
	

