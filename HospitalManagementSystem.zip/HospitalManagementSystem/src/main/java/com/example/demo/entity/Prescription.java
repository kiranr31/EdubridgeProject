package com.example.demo.entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="prescription")

public class Prescription {
	
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "prescription_id")
	    private int prescriptionId; 
	
	   @ManyToOne
	   @JsonIgnore
	   @JoinColumn(name="patient_Id")
	   private  Patient patient;
	   
	   @ManyToOne
	   @JsonIgnore
	   @JoinColumn(name ="Doctor_Id")
	   private Doctor doctor;
	   
	   @Column(name="medicines")
	   private String medicines;
	   
	   @Column(name="timing")
	   private String timing;
	   
	   @Column(name="noOfDays")
	   private int noOfDays;
	   
	   @Column(name="revisitDate")
	   private Date revisitDate;


	

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	public Doctor getDoctor() {
		return doctor;
	}

	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}

	

	public String getMedicines() {
		return medicines;
	}

	public void setMedicines(String medicines) {
		this.medicines = medicines;
	}

	public String getTiming() {
		return timing;
	}

	public void setTiming(String timing) {
		this.timing = timing;
	}

	

	public Date getRevisitDate() {
		return revisitDate;
	}

	public void setRevisitDate(Date revisitDate) {
		this.revisitDate = revisitDate;
	}

	public int getPrescriptionId() {
		return prescriptionId;
	}

	public void setPrescriptionId(int prescriptionId) {
		this.prescriptionId = prescriptionId;
	}

	public int getNoOfDays() {
		return noOfDays;
	}

	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}
	  
	   
	   
	   
	
	

}
