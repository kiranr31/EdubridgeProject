package com.example.demo.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Doctor;
import com.example.demo.entity.Patient;
import com.example.demo.repository.DoctorRepository;
import com.example.demo.repository.PatientRepository;
import com.example.demo.service.PatientService;
@Service
public class PatientServiceImpl implements PatientService {
	

	    @Autowired
	    private PatientRepository patientRepository;
	    
	    @Autowired
	    private DoctorRepository doctorRepository;

	    @Override
	    public Patient signIn(Patient patient) {
	       return patientRepository.findByEmailAndPassword(patient.getEmail(),patient.getPassword());
	    }

	    @Override
	    public Patient signUp(Patient patient) {
	       
	      
	      return  patientRepository.save(patient);
	    }

	   
	    @Override
	    public void updatePatient(Patient patient) {
	        patientRepository.save(patient);
	    }

	    @Override
	    public List<Patient> getAllPatients() {
	        return patientRepository.findAll();
	    }

	    @Override
	    public void deletePatient(Integer id) {
	        patientRepository.deleteById(id);
	    }

		@Override
		public Patient getPatientById(int patientId) {
			// TODO Auto-generated method stub
			return patientRepository.getById(patientId);
		}

	    

	   
	


}