package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Prescription;

public interface PrescriptionService {
	
	  Prescription addPrescription(Prescription prescription,int patientId,int doctorId);
	    List<Prescription> getPrescriptionsByPatientId(int patientId);

}
