package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Prescription;
import com.example.demo.service.PrescriptionService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/prescription")
public class PrescriptionController {
	
	 @Autowired
	    private PrescriptionService prescriptionService;
	 
	 private Prescription prescription1; 

	    // Add Prescription
	    @PostMapping("/add/{patientId}/{doctorId}")
	    public Prescription addPrescription(@PathVariable("patientId") int patientId, @PathVariable("doctorId") int doctorId, @RequestBody Prescription prescription) {
	    	
	    System.out.println(patientId);
	    System.out.println(doctorId);
	    System.out.println(prescription);
	        return prescriptionService.addPrescription(prescription,patientId,doctorId);
	    }

	    // Get Prescription by Patient ID
	    @GetMapping("/patient/{patientId}")
	    public List<Prescription> getPrescriptionsByPatientId(@PathVariable("patientId") int patientId) {
	    	System.out.println(patientId);
	        return prescriptionService.getPrescriptionsByPatientId(patientId);
	    }
	}



