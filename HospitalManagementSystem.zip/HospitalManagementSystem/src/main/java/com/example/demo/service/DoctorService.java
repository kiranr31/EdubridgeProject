package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Doctor;

public interface DoctorService {
	
	   Doctor signIn(Doctor doctor );
       Doctor signUp(Doctor doctor);

	   List<Doctor> getAllDoctors();
	   void updateDoctor(Doctor doctor);
	   void deleteDoctor(Integer id);
	   Doctor getDoctorById(int doctorId);
	
     
	

}
