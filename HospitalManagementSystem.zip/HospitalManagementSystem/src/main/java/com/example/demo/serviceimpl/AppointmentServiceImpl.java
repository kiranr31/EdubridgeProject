package com.example.demo.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Appointment;
import com.example.demo.entity.Doctor;
import com.example.demo.entity.Patient;
import com.example.demo.repository.AppointmentRepository;
import com.example.demo.repository.DoctorRepository;
import com.example.demo.repository.PatientRepository;
import com.example.demo.service.AppointmentService;

@Service
public class AppointmentServiceImpl implements AppointmentService {

	@Autowired
	private  AppointmentRepository appointmentRepository;
	
	@Autowired
	private PatientRepository patientRepository;
	
	@Autowired
	private DoctorRepository doctorRepository;

	 public AppointmentServiceImpl(AppointmentRepository appointmentRepository) {
	        this.appointmentRepository = appointmentRepository;
	    }

	    @Override
	    public List<Appointment> getAllAppointments() {
	        return appointmentRepository.findAll();
	    }

	    @Override
	    public Optional<Appointment> getAppointmentById(Integer id) {
	        return appointmentRepository.findById(id);
	                
	    }

	   
	    @Override
	    public void bookAppointment( int doctorId,int patientId, Appointment appoint) {
	        // Implement logic to book appointment
	    	 Patient patient = patientRepository.findById(patientId).orElse(null);
	         Doctor doctor = doctorRepository.findById(doctorId).orElse(null);

	         if (patient == null || doctor == null) {
	             System.out.println("Invalid patient or doctor ID.");
	             return;
	         }

	         patient.setDoctor(doctor);
	         patientRepository.save(patient);
	         appoint.setDoctor(doctor);
	         appoint.setPatient(patient);
	         appointmentRepository.save(appoint);
	         System.out.println("Appointment booked for patient " + patient.getName() + " with Dr. " + doctor.getName());
	     }
	    
	    @Override
		public void viewAppointments(Integer doctorId) {
			 Doctor doctor = doctorRepository.findById(doctorId).orElse(null);
		        if (doctor != null) {
		            System.out.println("Appointments for Dr. " + doctor.getName() + ":");
		          
		        } else {
		            System.out.println("Doctor not found.");
		        }
		    }
	    @Override
	    public List<Appointment> getAppointmentsByDoctorId(Integer doctorId) {
	        return appointmentRepository.findByDoctorId(doctorId);
	    }
	}



