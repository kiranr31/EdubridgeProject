package com.example.demo.serviceimpl;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Doctor;
import com.example.demo.entity.Patient;
import com.example.demo.entity.Prescription;
import com.example.demo.repository.PrescriptionRepository;
import com.example.demo.service.DoctorService;
import com.example.demo.service.PatientService;
import com.example.demo.service.PrescriptionService;

@Service
public class PrescriptionServiceImpl implements PrescriptionService {
	
	 @Autowired
	    private PrescriptionRepository prescriptionRepository;
	 
	 @Autowired
	 private PatientService patientService;
	 
	 @Autowired
	 private DoctorService doctorService;

	@Override
	public Prescription addPrescription(Prescription prescription,int patientId,int doctorId) {
		// TODO Auto-generated method stub
		System.out.println(prescription);
		Patient patient= patientService.getPatientById(patientId);
		Doctor doctor=doctorService.getDoctorById(doctorId);
		prescription.setPatient(patient);
		prescription.setDoctor(doctor);
		return prescriptionRepository.save(prescription);
	}

	@Override
	public List<Prescription> getPrescriptionsByPatientId(int patientId) {
		// TODO Auto-generated method stub
		return prescriptionRepository.findByPatientPatientId(patientId);
	}
	

	  
}
