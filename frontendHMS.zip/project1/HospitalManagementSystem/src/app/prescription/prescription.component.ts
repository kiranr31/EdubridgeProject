import { Component, OnInit } from '@angular/core';
import { Prescription } from '../../model/prescription';
import { ActivatedRoute, Router } from '@angular/router';
import { PrescriptionService } from '../prescription.service';

@Component({
  selector: 'app-prescription',
  standalone: false,
  
  templateUrl: './prescription.component.html',
  styleUrl: './prescription.component.css'
})
export class PrescriptionComponent  implements OnInit{
  constructor(private router:Router, private prescriptionService:PrescriptionService, private activatedRoute:ActivatedRoute){}

  prescription= new Prescription();
  
  medicinesList:string[]=[];
  timingsList:string[]=[]; 
patientId:any;
doctorId:any;
  ngOnInit(): void {
    this.patientId=this.activatedRoute.snapshot.params['patientId'];
    this.doctorId=this.activatedRoute.snapshot.params['doctorId'];
  }

  
  submitPrescription()
  {
    console.log(this.medicinesList);
    console.log(this.timingsList);
    for(let m of this.medicinesList){
      this.prescription.medicines +=( m + " ");
    }
    for(let t of this.timingsList){
      this.prescription.timing += (t+ " ");
    }
    console.log(this.prescription.medicines);
    console.log(this.prescription.timing);
    this.prescriptionService.addPrescription(this.prescription,this.patientId,this.doctorId).subscribe(

      (response:any)=>
        alert("works")
    )
  }
  toggleMedicineSelection(medicine: string): void {
    const index = this.medicinesList.indexOf(medicine);
    if (index > -1) {
      this.medicinesList.splice(index, 1); // Remove the medicine if already selected
    } else {
      this.medicinesList.push(medicine); // Add the medicine if not selected
    }
  }
  toggleTimingSelection(timing:string): void {
    const index = this.timingsList.indexOf(timing);
    if (index > -1) {
      this.timingsList.splice(index, 1); // Remove the timing if already selected
    } else {
      this.timingsList.push(timing); // Add the timing if not selected
    }
  }


 
 
}
