import { Component } from '@angular/core';

@Component({
  selector: 'app-viewappointments',
  standalone: false,
  
  templateUrl: './viewappointments.component.html',
  styleUrl: './viewappointments.component.css'
})
export class ViewappointmentsComponent {

}
