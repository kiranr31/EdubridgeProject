import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-doctorpage',
  standalone: false,
  
  templateUrl: './doctorpage.component.html',
  styleUrl: './doctorpage.component.css'
})
export class DoctorpageComponent {
  constructor(private router:Router){}
  signUp(){
    this.router.navigate(['doctorsignupurl']);
  }
signIn(){
  this.router.navigate(['doctorsigninurl']);
}
}
