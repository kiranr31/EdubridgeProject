import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { DoctorpageComponent } from './doctorpage/doctorpage.component';
import { PatientpageComponent } from './patientpage/patientpage.component';

import { FormsModule, NgForm, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { DoctorsignupComponent } from './doctorsignup/doctorsignup.component';

import { DoctorsigninComponent } from './doctorsignin/doctorsignin.component';
import { PatientsignupComponent } from './patientsignup/patientsignup.component';
import { PatientsigninComponent } from './patientsignin/patientsignin.component';
import { DochomepageComponent } from './dochomepage/dochomepage.component';
import { PatihomepageComponent } from './patihomepage/patihomepage.component';
import { BookappointmentComponent } from './bookappointment/bookappointment.component';
import { ViewappointmentsComponent } from './viewappointments/viewappointments.component';
import { AdminhomepageComponent } from './adminhomepage/adminhomepage.component';
import { PrescriptionComponent } from './prescription/prescription.component';
import { ViewprescriptionComponent } from './viewprescription/viewprescription.component';

@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent,
    AdminpageComponent,
    DoctorpageComponent,
    PatientpageComponent,
    DoctorsignupComponent,
   
    DoctorsigninComponent,
         PatientsignupComponent,
         PatientsigninComponent,
         DochomepageComponent,
         PatihomepageComponent,
         BookappointmentComponent,
         ViewappointmentsComponent,
         AdminhomepageComponent,
         PrescriptionComponent,
         ViewprescriptionComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
   HttpClientModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
