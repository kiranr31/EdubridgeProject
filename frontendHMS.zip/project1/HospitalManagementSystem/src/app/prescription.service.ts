import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PrescriptionService {
  url="http://localhost:8089/prescription"

  constructor(private httpClient:HttpClient) { }

  addPrescription(prescription:any,patientId:any,doctorId:any)
  {
   return this.httpClient.post(`${this.url}/add/${patientId}/${doctorId}`,prescription);
  }

  getPrescriptionByPatientId(patientId:any)
  {
    return this.httpClient.get(`${this.url}/patient/${patientId}`);
  }

}
