import { Component } from '@angular/core';
import { Router } from '@angular/router';

import { Patient } from '../../model/patient';
import { PatientService } from '../patient.service';

@Component({
  selector: 'app-patientsignup',
  standalone: false,
  
  templateUrl: './patientsignup.component.html',
  styleUrl: './patientsignup.component.css'
})
export class PatientsignupComponent {
  constructor(private router:Router, private patientService:PatientService){}
       patient = new Patient();
       onSubmit(){
      this.patientService.addPatient(this.patient).subscribe(
        (response:any)=>
          this.router.navigate(['patientsigninurl'])
      )
      
       }
      
       onBack(){
        this.router.navigate(['patientpageurl']);
       }
  
  

}
