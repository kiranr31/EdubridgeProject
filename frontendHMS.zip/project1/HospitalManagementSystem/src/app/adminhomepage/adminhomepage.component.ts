import { Component } from '@angular/core';

@Component({
  selector: 'app-adminhomepage',
  standalone: false,
  
  templateUrl: './adminhomepage.component.html',
  styleUrl: './adminhomepage.component.css'
})
export class AdminhomepageComponent {

}
