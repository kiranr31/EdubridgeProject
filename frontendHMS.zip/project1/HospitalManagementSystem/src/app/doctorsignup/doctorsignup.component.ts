import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { DoctorService } from '../service/doctor.service';
import { Doctor } from '../../doctor';
@Component({
  selector: 'app-doctorsignup',
  standalone: false,
  
  templateUrl: './doctorsignup.component.html',
  styleUrl: './doctorsignup.component.css'
})
export class DoctorsignupComponent {
   constructor(private router:Router,private doctorService: DoctorService){}
   doctor=new Doctor();
   onSubmit(){
    this.doctorService.addDoctor(this.doctor).subscribe(
      (response:any)=>{
        alert("doctor registered successfully");
        this.router.navigate(['doctorsigninurl']);
      }
      
    )
   
   }
   onBack(){
    this.router.navigate(['welcomepageurl']);
   }


}
