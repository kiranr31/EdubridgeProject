import { Component } from '@angular/core';

@Component({
  selector: 'app-bookappointment',
  standalone: false,
  
  templateUrl: './bookappointment.component.html',
  styleUrl: './bookappointment.component.css'
})
export class BookappointmentComponent {

}
