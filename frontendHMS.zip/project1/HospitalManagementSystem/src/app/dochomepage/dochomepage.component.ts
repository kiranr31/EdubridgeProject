import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PatientService } from '../patient.service';

@Component({
  selector: 'app-dochomepage',
  standalone: false,
  
  templateUrl: './dochomepage.component.html',
  styleUrl: './dochomepage.component.css'
})
export class DochomepageComponent implements OnInit{
  appointmentDetails:any;
  doctorId:any;
  requestprescription:boolean=false;
  
  constructor(private router:Router,private patientService:PatientService,private activatedRoute:ActivatedRoute){}
  
  ngOnInit(): void{
 this.doctorId=this.activatedRoute.snapshot.params['doctorId'];
this.patientService.getAppointmentByDoctorId(this.doctorId).subscribe(
  (response:any)=>
  {
    this.appointmentDetails=response;
  }
)
  }
  viewAppointment()
  {
    
  }
  prescription(patientId:any){
    this.router.navigate(['prescriptionpageurl',patientId,this.doctorId]);
   }

   
  
}