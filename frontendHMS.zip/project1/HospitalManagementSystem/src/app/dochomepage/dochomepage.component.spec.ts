import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DochomepageComponent } from './dochomepage.component';

describe('DochomepageComponent', () => {
  let component: DochomepageComponent;
  let fixture: ComponentFixture<DochomepageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DochomepageComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DochomepageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
