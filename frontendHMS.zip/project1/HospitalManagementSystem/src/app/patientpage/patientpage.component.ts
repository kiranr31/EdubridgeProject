import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-patientpage',
  standalone: false,
  
  templateUrl: './patientpage.component.html',
  styleUrl: './patientpage.component.css'
})
export class PatientpageComponent {
  constructor(private router:Router){}
    signUp(){
      this.router.navigate(['patientsignupurl']);
    }
  signIn(){
    this.router.navigate(['patientsigninurl']);
  }
  Onback(){
    this.router.navigate(['welcomepageurl']);
  }

}
