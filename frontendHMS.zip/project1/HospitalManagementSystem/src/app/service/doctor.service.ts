import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DoctorService {
  url="http://localhost:8089/doctor";
  url1="http://localhost:8089/api/appointments";
  
   constructor(private httpClient:HttpClient) { }

  addDoctor(doctor:any)
  {
return this.httpClient.post(`${this.url}/signUp`,doctor);
  }
  loginDoctor(doctor:any)
  {
    return this.httpClient.post(`${this.url}/signIn`,doctor);
  }
  getAllDoctors()
  {
    return this.httpClient.get(`${this.url}`);
  }
  getAppointment(doctorId:any, patientId:any, appointment:any)
  {
return this.httpClient.post (`${this.url1}/bookAppointment/${doctorId}/${patientId}`,appointment);
  }
  
}
