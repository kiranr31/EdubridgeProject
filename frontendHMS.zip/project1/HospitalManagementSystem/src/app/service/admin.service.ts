import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
url="http://localhost:8089/admin/login"
  constructor(private httpClient:HttpClient) { }
 /* public checkAdmin(username:any,password:any)
  {
    console.log(username);
    console.log(password);
    return this.httpClient.post(`${this.url}/${username}/${password}`);
  }*/
  public loginAdmin(admin:any)
  {
    console.log(admin);
    //console.log(password);
    return this.httpClient.post(`${this.url}`,admin);
  }
}
