import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { WelcomeComponent } from './welcome/welcome.component';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { DoctorpageComponent } from './doctorpage/doctorpage.component';
import { PatientpageComponent } from './patientpage/patientpage.component';

import { NgForm } from '@angular/forms';
import { DoctorsignupComponent } from './doctorsignup/doctorsignup.component';
import { DoctorsigninComponent } from './doctorsignin/doctorsignin.component';
import { PatientsignupComponent } from './patientsignup/patientsignup.component';
import { PatientsigninComponent } from './patientsignin/patientsignin.component';
import { DochomepageComponent } from './dochomepage/dochomepage.component';
import { PatihomepageComponent } from './patihomepage/patihomepage.component';
import { BookappointmentComponent } from './bookappointment/bookappointment.component';
import { ViewappointmentsComponent } from './viewappointments/viewappointments.component';
import { AdminhomepageComponent } from './adminhomepage/adminhomepage.component';
import { PrescriptionComponent } from './prescription/prescription.component';
import { ViewprescriptionComponent } from './viewprescription/viewprescription.component';

const routes: Routes = [{path:"",component:WelcomeComponent},
  {path:"adminpageurl",component:AdminpageComponent},
  {path:"doctorpageurl",component:DoctorpageComponent},
  {path:"patientpageurl",component:PatientpageComponent},
  {path:"welcomepageurl",component:WelcomeComponent},
  {path:"doctorsignupurl",component:DoctorsignupComponent},
  {path:"doctorsigninurl",component:DoctorsigninComponent},
  {path:"patientsignupurl",component:PatientsignupComponent},
  {path:"patientsigninurl",component:PatientsigninComponent},
  {path:"dochomepageurl/:doctorId",component:DochomepageComponent},
  {path:"patihomepageurl/:patientId",component:PatihomepageComponent},
  {path:"appointmentpageurl",component:BookappointmentComponent},
  {path:"viewappointmenturl",component:ViewappointmentsComponent},
  {path:"adminhomepageurl",component:AdminhomepageComponent},
  {path:"prescriptionpageurl/:patientId/:doctorId",component:PrescriptionComponent},
  {path:"viewprescriptionpageurl/:patientId",component:ViewprescriptionComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  

})
export class AppRoutingModule { }
