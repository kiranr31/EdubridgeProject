import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Patient } from '../../model/patient';
import { PatientService } from '../patient.service';


@Component({
  selector: 'app-patientsignin',
  standalone: false,
  
  templateUrl: './patientsignin.component.html',
  styleUrl: './patientsignin.component.css'
})
export class PatientsigninComponent {
  patientId:any;

  constructor(private router:Router, private patientService:PatientService){}
       patient= new Patient();
       onSubmit(){
        this.patientService.loginPatient(this.patient).subscribe(
          (Response:any)=>
          {
            if(Response != null){
              this.patientId = Response.patientId;
              alert("sign in success");
              console.log(this.patientId);
            this.router.navigate(['patihomepageurl',this.patientId]);}
            
              else{
                alert("sign in failed");
            }
          }
          
        
        )
      }
       onBack(){
        this.router.navigate(['patientpageurl']);
       }
  

}
