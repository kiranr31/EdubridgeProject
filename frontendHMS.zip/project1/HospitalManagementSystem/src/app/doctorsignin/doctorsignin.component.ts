import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { DoctorService } from '../service/doctor.service';
import { Doctor } from '../../doctor';

@Component({
  selector: 'app-doctorsignin',
  standalone: false,
  
  templateUrl: './doctorsignin.component.html',
  styleUrl: './doctorsignin.component.css'
})

export class DoctorsigninComponent {
   constructor(private router:Router, private doctorservice:DoctorService){}
   doctorId:any;
     doctor= new Doctor();
     onSubmit(){
      this.doctorservice.loginDoctor(this.doctor).subscribe(
        (Response:any)=>
        {
          if(Response != null){
          alert("sign in success");
          this.doctor=Response;
          this.doctorId=this.doctor.id;
          this.router.navigate(['dochomepageurl',this.doctorId]);
          }else{
            alert("sign in failed");
          }
        }
      )
      

      }
     
     
     onBack(){
      this.router.navigate(['doctorpageurl']);
     }
    }
    
  
  


