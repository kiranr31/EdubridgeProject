import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DoctorService } from '../service/doctor.service';
import { Appointment } from '../../model/appointment';
import { AbstractControl } from '@angular/forms';


@Component({
  selector: 'app-patihomepage',
  standalone: false,
  
  templateUrl: './patihomepage.component.html',
  styleUrl: './patihomepage.component.css'
})
export class PatihomepageComponent implements OnInit {
  doctorDetails:any;
  patientId:any
  appointDate:any;
  appointTime:any;
  availableTimes: string[] = [
    '12:00 AM', '01:00 AM', '02:00 AM', '03:00 AM', '04:00 AM', '05:00 AM', '06:00 AM', '07:00 AM', '08:00 AM', '09:00 AM', '10:00 AM', '11:00 AM',
    '12:00 PM', '01:00 PM', '02:00 PM', '03:00 PM', '04:00 PM', '05:00 PM', '06:00 PM', '07:00 PM', '08:00 PM', '09:00 PM', '10:00 PM', '11:00 PM'
  ];
  appointaoption:boolean=false;
  appointment=new Appointment(new Date(),"");
  doctorId :any; 
  
  constructor(private router:Router,private doctorService:DoctorService, private activatedRoute:ActivatedRoute){}
  ngOnInit(): void {
    
    this.patientId=this.activatedRoute.snapshot.params['patientId'];
        this.doctorService.getAllDoctors().subscribe(
      (response:any)=>
      {
        this.doctorDetails=response;
      }
    )
  }
  takeAppoint(doctorId:any)
  {
    this.appointaoption=true;
    this.doctorId=doctorId
  }
  getAppoint()
  {
    this.appointment.appointmentDate=this.appointDate;
    this.appointment.appointmentTime=this.appointTime;
    console.log(this.appointment);
this.doctorService.getAppointment(this.doctorId,this.patientId,this.appointment).subscribe(
  (response:any)=>{
    if (this.appointDate && this.appointTime) {
      const selectedDate = new Date(this.appointDate);
      const today = new Date();
      today.setHours(0, 0, 0, 0); // Reset today's time to 00:00:00

      if (selectedDate > today) {
        // Logic to handle appointment booking
        console.log(`Appointment Date: ${this.appointDate}, Appointment Time: ${this.appointTime}`);
        alert(`Appointment Date: ${this.appointDate}, Appointment Time: ${this.appointTime}`);
      } else {
        alert('Please select a date greater than today.');
      }
    } else {
      alert('Please select both date and time for the appointment.');
    }
  }
)
  }

  Prescription()
  {
    this.router.navigate(['viewprescriptionpageurl',this.patientId]);
  }

  
  Onback(){
    this.router.navigate(['patientsigninurl']);
  }
 
}
