import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PatihomepageComponent } from './patihomepage.component';

describe('PatihomepageComponent', () => {
  let component: PatihomepageComponent;
  let fixture: ComponentFixture<PatihomepageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PatihomepageComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PatihomepageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
