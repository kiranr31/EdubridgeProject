import { AnimateTimings } from '@angular/animations';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PatientService } from '../patient.service';
import { DoctorService } from '../service/doctor.service';
import { PrescriptionService } from '../prescription.service';

@Component({
  selector: 'app-viewprescription',
  standalone: false,
  
  templateUrl: './viewprescription.component.html',
  styleUrl: './viewprescription.component.css'
})
export class ViewprescriptionComponent implements OnInit{

  prescriptionDetails: any;
  prescription:any;
  patientId:any;

  constructor(private router:Router,private prescriptionService:PrescriptionService,private activatedRoute:ActivatedRoute){}

  ngOnInit(): void {
    this.patientId=this.activatedRoute.snapshot.params['patientId'];
    this.prescriptionService.getPrescriptionByPatientId(this.patientId).subscribe(
      (response:any)=>
      {
        console.log(this.patientId);
        this.prescriptionDetails=response;
      }
    )
    
  }
}
