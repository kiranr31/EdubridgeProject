import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { WelcomeComponent } from '../welcome/welcome.component';
import { Admin } from '../../admin';
import { AdminService } from '../service/admin.service';

@Component({
  selector: 'app-adminpage',
  standalone: false,
  
  templateUrl: './adminpage.component.html',
  styleUrl: './adminpage.component.css'
})
export class AdminpageComponent {
 admin =new Admin(0,"","");

  constructor(private router:Router,private adminService:AdminService){
   }
   onSubmit(){
    console.log(this.admin);
    
      this.adminService.loginAdmin(this.admin).subscribe(
  (response:any)=>
  {
    console.log(response);
    if (response !=  null){
      alert("admin login success" );
      this.router.navigate(['adminhomepageurl']);
    }
    else{
    alert("admin login failed");
    }
  }
)  }

Onback(){
  this.router.navigate(['welcomepageurl']);
} 

}
