import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PatientService {
url="http://localhost:8089/patient"
url1="http://localhost:8089/api/appointments";
constructor(private httpClient:HttpClient) {}
   addPatient(patient:any)
    {
      return this.httpClient.post(`${this.url}/signUp`,patient);
    }
    loginPatient(patient:any)
    {
      return this.httpClient.post(`${this.url}/signIn`,patient)
    }
    getAllPatients()
    {
      return this.httpClient.get(`${this.url}`);
    }
    /*viewAppointment(patientId:any,doctorId:any,doctor:any)
    {
      return this.httpClient.post(`${this.url1}/viewAppointment/${patientId},${doctorId}`,doctor);
    }*/
    getAppointmentByDoctorId(doctorId:any)
    {
      return this.httpClient.get(`${this.url1}/doctor/${doctorId}`);
    }

 
      }
