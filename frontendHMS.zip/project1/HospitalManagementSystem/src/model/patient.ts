export class Patient{
    patientId:number | null;
    name:string;
   email:string;
    password:string;
    gender:string;
    age:number;
    

    constructor(){
       
        this.patientId=null;
        this.name='';
        this.email='';
        this.password='';
        this.gender='';
        this.age=0;
        
      
    }
    

}