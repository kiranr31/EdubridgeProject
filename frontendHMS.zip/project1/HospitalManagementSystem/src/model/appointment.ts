import { Time } from "@angular/common";

export class Appointment{

   // appointmentId:number;
    appointmentDate:Date;
    appointmentTime:string;

    constructor(appointmentDate:Date,appointmentTime:string ) {

        //this.appointmentId=appointmentId;
        this.appointmentDate=appointmentDate;
        this.appointmentTime=appointmentTime;
    }

}