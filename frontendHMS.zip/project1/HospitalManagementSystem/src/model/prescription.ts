export class Prescription
{
   id :number |null ;
   medicines:string;
   timing:string;
   noOfDays:number;
   revisitDate:Date;

   constructor(){
    this.id =null;
this.medicines='';
this.timing='';
this.noOfDays=0;
this.revisitDate=new Date();
   }


}