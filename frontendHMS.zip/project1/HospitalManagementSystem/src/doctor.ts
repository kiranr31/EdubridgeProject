export class Doctor{
  id!:number | null;
    name:string;
   email:string;
    password:string;
    specialization:string;
   
    constructor() {
      this.id = null; // Use null for new entities
      this.name = '';
      this.specialization = '';
      this.email='';
      this.password='';

    }

}
